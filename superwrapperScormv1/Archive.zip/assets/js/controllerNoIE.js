alert('Sorry this website is not compatible with older versions of IE Explorer.  Please use google chrome, firefox or safari');

